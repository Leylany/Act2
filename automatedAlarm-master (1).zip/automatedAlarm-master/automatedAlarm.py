# automatedAlarm.py
# by _______

# Write function defintion: automatedAlarm()

# Make sure it returns a value

if __name__ == '__main__':
    # Call the function in here if you want to test it
    # Make sure it's indented
    pass # remove or comment out this line if you wish to test the function
